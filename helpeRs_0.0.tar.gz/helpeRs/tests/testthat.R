# This file is the main test runner for the helpeRs package
# Run all tests with: devtools::test() or testthat::test_dir("tests/testthat")

library(testthat)
library(helpeRs)

test_check("helpeRs")
